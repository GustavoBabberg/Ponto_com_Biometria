const express = require("express");
const { SerialPort } = require("serialport");
const { ReadlineParser } = require("@serialport/parser-readline");
const sqlite3 = require("sqlite3");
const { Server } = require("socket.io");
const http = require("http");
const cors = require('cors');

const app = express();
const server = http.createServer(app);
const io = new Server(server);

app.use(cors());
app.use(express.static("public"));

const db = new sqlite3.Database("data.db");
db.run(`
  CREATE TABLE IF NOT EXISTS logins (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    digitalID INTEGER,
    nome TEXT,
    hora TEXT
  )
`);

const port = new SerialPort({ path: "COM9", baudRate: 9600 });
const parser = port.pipe(new ReadlineParser({ delimiter: "\n" }));

const idToName = {
  1: "Kaio Matteucci Murata",
  2: "Gustavo Rossi Babberg Lima",
  3: "Guilherme Henrique Nobile Silva",
};

parser.on("data", (line) => {
  line = line.trim();

  console.log("Recebido:", line);

  if (line.startsWith("VALIDACAO:")) {
    const digitalID = line.replace("VALIDACAO:", "").trim();

    if (digitalID && digitalID !== "ERRO") {
      const nome = idToName[digitalID] || "Desconhecido";
      const hora = new Date().toLocaleString("pt-BR");

      db.run(
        `INSERT INTO logins (digitalID, nome, hora) VALUES (?, ?, ?)`,
        [digitalID, nome, hora],
        function (err) {
          if (err) console.error(err);
          else {
            const dado = { id: this.lastID, digitalID, nome, hora };
            console.log("Login salvo:", dado);
            io.emit("novaValidacao", dado); // Envia em tempo real pro HTML
          }
        }
      );
    }
  }
});

app.get("/logs", (req, res) => {
  db.all("SELECT * FROM logins ORDER BY id DESC", (err, rows) => {
    if (err) res.status(500).send(err);
    else res.json(rows);
  });
});

server.listen(3000, '0.0.0.0', () =>
  console.log("Servidor rodando em http://localhost:3000") // Ngrok: https://coleen-unruddered-itchingly.ngrok-free.dev
);
