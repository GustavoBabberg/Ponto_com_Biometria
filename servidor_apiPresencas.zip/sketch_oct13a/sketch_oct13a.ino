#include <Wire.h>
#include <LiquidCrystal_I2C.h>
#include <Adafruit_Fingerprint.h>
#include <SoftwareSerial.h>

SoftwareSerial mySerial(6, 7); // RX, TX
Adafruit_Fingerprint finger(&mySerial);
LiquidCrystal_I2C lcd(0x27, 16, 2);

const int botaoCadastrar = 2;
const int botaoValidar = 3;
const int botaoLimpar = 4; // Botão para apagar digitais

String nomeUsuario = "";

void setup() {
  Serial.begin(9600);
  mySerial.begin(57600);

  pinMode(botaoCadastrar, INPUT_PULLUP);
  pinMode(botaoValidar, INPUT_PULLUP);
  pinMode(botaoLimpar, INPUT_PULLUP);

  lcd.init();
  lcd.backlight();
  lcd.setCursor(0, 0);
  lcd.print("Sistema pronto");
  lcd.setCursor(0, 1);
  lcd.print("Botao1=Cadastrar");

  if (finger.verifyPassword()) {
    lcd.setCursor(0, 1);
    lcd.print("Sensor OK ");
  } else {
    lcd.setCursor(0, 1);
    lcd.print("Sensor ERRO ");
    while (1);
  }

  finger.getTemplateCount();
  Serial.print("Digitais armazenadas: ");
  Serial.println(finger.templateCount);
}

void loop() {
  if (digitalRead(botaoCadastrar) == HIGH) { // corrigido para LOW, botao INPUT_PULLUP
    lcd.clear();
    lcd.print("=== CADASTRO ===");

    finger.getTemplateCount();
    uint8_t novoID = finger.templateCount + 1;

    if (novoID > 127) {
      lcd.clear();
      lcd.print("Memoria cheia");
      delay(2000);
    } else {
      Serial.println("Digite o nome do usuario e pressione Enter:");
      nomeUsuario = "";

      while (nomeUsuario.length() == 0) {
        if (Serial.available()) {
          nomeUsuario = Serial.readStringUntil('\n');
          nomeUsuario.trim();
        }
      }

      Serial.print("Nome recebido: ");
      Serial.println(nomeUsuario);
      cadastrarDigital(novoID);
    }
    delay(1000);
  }

  if (digitalRead(botaoValidar) == HIGH) { // corrigido para LOW, botao INPUT_PULLUP
    lcd.clear();
    lcd.print("=== VALIDACAO ===");
    validarDigital();
    delay(1000);
  }

  if (digitalRead(botaoLimpar) == HIGH) { // corrigido para LOW, botao INPUT_PULLUP
    lcd.clear();
    lcd.print("Apagando digitais...");
    Serial.println("Apagando digitais...");

    if (finger.emptyDatabase() == FINGERPRINT_OK) {
      lcd.clear();
      lcd.print("Digitais apagadas");
      Serial.println("Todas digitais apagadas!");
    } else {
      lcd.clear();
      lcd.print("Erro ao apagar");
      Serial.println("Erro ao apagar todas digitais!");
    }
    delay(2000);
  }
}

void cadastrarDigital(uint8_t id) {
  int p = -1;

  lcd.clear();
  lcd.print("Coloque o dedo...");
  while (p != FINGERPRINT_OK) p = finger.getImage();

  p = finger.image2Tz(1);
  if (p != FINGERPRINT_OK) {
    lcd.clear();
    lcd.print("Erro processar");
    delay(2000);
    return;
  }

  p = finger.fingerFastSearch();
  if (p == FINGERPRINT_OK) {
    lcd.clear();
    lcd.print("Ja cadastrado!");
    lcd.setCursor(0, 1);
    lcd.print("ID:");
    lcd.print(finger.fingerID);
    delay(2000);
    return;
  }

  lcd.clear();
  lcd.print("Remova o dedo");
  delay(2000);
  while (finger.getImage() != FINGERPRINT_NOFINGER);

  lcd.clear();
  lcd.print("Repita o dedo...");
  p = -1;
  while (p != FINGERPRINT_OK) p = finger.getImage();
  finger.image2Tz(2);

  if (finger.createModel() == FINGERPRINT_OK) {
    if (finger.storeModel(id) == FINGERPRINT_OK) {
      lcd.clear();
      lcd.print("Digital cadastrada");
      lcd.setCursor(0, 1);
      lcd.print("ID:");
      lcd.print(id);
      delay(2000);

      // Envia cadastro para o servidor: ID + Nome
      Serial.print("CADASTRO:");
      Serial.print(id);
      Serial.print(";NOME:");
      Serial.println(nomeUsuario);
    } else {
      lcd.clear();
      lcd.print("Erro ao salvar ID");
      delay(2000);
    }
  } else {
    lcd.clear();
    lcd.print("Digitais nao coincidem");
    delay(2000);
  }
}

void validarDigital() {
  int p = -1;

  lcd.clear();
  lcd.print("Coloque o dedo...");
  while (p != FINGERPRINT_OK) p = finger.getImage();

  finger.image2Tz();

  if (finger.fingerFastSearch() == FINGERPRINT_OK) {
    lcd.clear();
    lcd.print("Digital reconhecida");
    lcd.setCursor(0, 1);
    lcd.print("ID:");
    lcd.print(finger.fingerID);

    // Envia só o ID para o servidor validar nome lá
    Serial.print("VALIDACAO:");
    Serial.println(finger.fingerID);
    delay(2000);
  } else {
    lcd.clear();
    lcd.print("Digital nao encontrada");
    Serial.println("VALIDACAO:ERRO");
    delay(2000);
  }
}